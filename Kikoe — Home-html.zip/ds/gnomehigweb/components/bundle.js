/* @ds-bundle: {"format":4,"namespace":"GnomeHigWeb","components":[{"name":"Icon"},{"name":"Button"},{"name":"Badge"},{"name":"Tag"},{"name":"Input"},{"name":"Alert"},{"name":"Card"},{"name":"Tile"},{"name":"ApplicationCard"},{"name":"Tabs"},{"name":"MultiToggle"},{"name":"Pagination"},{"name":"Switch"},{"name":"Spinner"},{"name":"Disclosure"},{"name":"Header"},{"name":"Footer"},{"name":"Breadcrumbs"},{"name":"DataTable"},{"name":"CodeCopy"}]} */
(function () {
  var React = window.React, h = React.createElement;
  var useState = React.useState, useEffect = React.useEffect, useId = React.useId;
  var ICONS={"chevron-right":[24,"<path fill-rule=\"evenodd\" d=\"M16.28 11.47a.75.75 0 0 1 0 1.06l-7.5 7.5a.75.75 0 0 1-1.06-1.06L14.69 12 7.72 5.03a.75.75 0 0 1 1.06-1.06l7.5 7.5Z\" clip-rule=\"evenodd\"/>"],"chevron-down":[20,"<path fill-rule=\"evenodd\" d=\"M5.22 8.22a.75.75 0 0 1 1.06 0L10 11.94l3.72-3.72a.75.75 0 1 1 1.06 1.06l-4.25 4.25a.75.75 0 0 1-1.06 0L5.22 9.28a.75.75 0 0 1 0-1.06Z\" clip-rule=\"evenodd\"/>"],"ellipsis-horizontal":[20,"<path d=\"M3 10a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0ZM8.5 10a1.5 1.5 0 1 1 3 0 1.5 1.5 0 0 1-3 0ZM15.5 8.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3Z\"/>"],"bars-3":[24,"<path fill-rule=\"evenodd\" d=\"M3 6.75A.75.75 0 0 1 3.75 6h16.5a.75.75 0 0 1 0 1.5H3.75A.75.75 0 0 1 3 6.75ZM3 12a.75.75 0 0 1 .75-.75h16.5a.75.75 0 0 1 0 1.5H3.75A.75.75 0 0 1 3 12Zm0 5.25a.75.75 0 0 1 .75-.75h16.5a.75.75 0 0 1 0 1.5H3.75a.75.75 0 0 1-.75-.75Z\" clip-rule=\"evenodd\"/>"],"x-mark":[24,"<path fill-rule=\"evenodd\" d=\"M5.47 5.47a.75.75 0 0 1 1.06 0L12 10.94l5.47-5.47a.75.75 0 1 1 1.06 1.06L13.06 12l5.47 5.47a.75.75 0 1 1-1.06 1.06L12 13.06l-5.47 5.47a.75.75 0 0 1-1.06-1.06L10.94 12 5.47 6.53a.75.75 0 0 1 0-1.06Z\" clip-rule=\"evenodd\"/>"],"magnifying-glass":[20,"<path fill-rule=\"evenodd\" d=\"M9 3.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11ZM2 9a7 7 0 1 1 12.452 4.391l3.328 3.329a.75.75 0 1 1-1.06 1.06l-3.329-3.328A7 7 0 0 1 2 9Z\" clip-rule=\"evenodd\"/>"],"plus":[20,"<path d=\"M10.75 4.75a.75.75 0 0 0-1.5 0v4.5h-4.5a.75.75 0 0 0 0 1.5h4.5v4.5a.75.75 0 0 0 1.5 0v-4.5h4.5a.75.75 0 0 0 0-1.5h-4.5v-4.5Z\"/>"],"check":[20,"<path fill-rule=\"evenodd\" d=\"M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.05-.143Z\" clip-rule=\"evenodd\"/>"],"information-circle":[24,"<path fill-rule=\"evenodd\" d=\"M2.25 12c0-5.385 4.365-9.75 9.75-9.75s9.75 4.365 9.75 9.75-4.365 9.75-9.75 9.75S2.25 17.385 2.25 12Zm8.706-1.442c1.146-.573 2.437.463 2.126 1.706l-.709 2.836.042-.02a.75.75 0 0 1 .67 1.34l-.04.022c-1.147.573-2.438-.463-2.127-1.706l.71-2.836-.042.02a.75.75 0 1 1-.671-1.34l.041-.022ZM12 9a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z\" clip-rule=\"evenodd\"/>"],"exclamation-triangle":[24,"<path fill-rule=\"evenodd\" d=\"M9.401 3.003c1.155-2 4.043-2 5.197 0l7.355 12.748c1.154 2-.29 4.5-2.599 4.5H4.645c-2.309 0-3.752-2.5-2.598-4.5L9.4 3.003ZM12 8.25a.75.75 0 0 1 .75.75v3.75a.75.75 0 0 1-1.5 0V9a.75.75 0 0 1 .75-.75Zm0 8.25a.75.75 0 1 0 0-1.5.75.75 0 0 0 0 1.5Z\" clip-rule=\"evenodd\"/>"],"check-circle":[20,"<path fill-rule=\"evenodd\" d=\"M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z\" clip-rule=\"evenodd\"/>"],"x-circle":[24,"<path fill-rule=\"evenodd\" d=\"M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm-1.72 6.97a.75.75 0 1 0-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 1 0 1.06 1.06L12 13.06l1.72 1.72a.75.75 0 1 0 1.06-1.06L13.06 12l1.72-1.72a.75.75 0 1 0-1.06-1.06L12 10.94l-1.72-1.72Z\" clip-rule=\"evenodd\"/>"],"arrow-down-tray":[20,"<path d=\"M10.75 2.75a.75.75 0 0 0-1.5 0v8.614L6.295 8.235a.75.75 0 1 0-1.09 1.03l4.25 4.5a.75.75 0 0 0 1.09 0l4.25-4.5a.75.75 0 0 0-1.09-1.03l-2.955 3.129V2.75Z\"/> <path d=\"M3.5 12.75a.75.75 0 0 0-1.5 0v2.5A2.75 2.75 0 0 0 4.75 18h10.5A2.75 2.75 0 0 0 18 15.25v-2.5a.75.75 0 0 0-1.5 0v2.5c0 .69-.56 1.25-1.25 1.25H4.75c-.69 0-1.25-.56-1.25-1.25v-2.5Z\"/>"],"home":[20,"<path fill-rule=\"evenodd\" d=\"M9.293 2.293a1 1 0 0 1 1.414 0l7 7A1 1 0 0 1 17 11h-1v6a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-6H3a1 1 0 0 1-.707-1.707l7-7Z\" clip-rule=\"evenodd\"/>"],"square-2-stack":[24,"<path d=\"M16.5 6a3 3 0 0 0-3-3H6a3 3 0 0 0-3 3v7.5a3 3 0 0 0 3 3v-6A4.5 4.5 0 0 1 10.5 6h6Z\"/> <path d=\"M18 7.5a3 3 0 0 1 3 3V18a3 3 0 0 1-3 3h-7.5a3 3 0 0 1-3-3v-7.5a3 3 0 0 1 3-3H18Z\"/>"],"sun":[20,"<path d=\"M10 2a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-1.5 0v-1.5A.75.75 0 0 1 10 2ZM10 15a.75.75 0 0 1 .75.75v1.5a.75.75 0 0 1-1.5 0v-1.5A.75.75 0 0 1 10 15ZM10 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6ZM15.657 5.404a.75.75 0 1 0-1.06-1.06l-1.061 1.06a.75.75 0 0 0 1.06 1.06l1.06-1.06ZM6.464 14.596a.75.75 0 1 0-1.06-1.06l-1.06 1.06a.75.75 0 0 0 1.06 1.06l1.06-1.06ZM18 10a.75.75 0 0 1-.75.75h-1.5a.75.75 0 0 1 0-1.5h1.5A.75.75 0 0 1 18 10ZM5 10a.75.75 0 0 1-.75.75h-1.5a.75.75 0 0 1 0-1.5h1.5A.75.75 0 0 1 5 10ZM14.596 15.657a.75.75 0 0 0 1.06-1.06l-1.06-1.061a.75.75 0 1 0-1.06 1.06l1.06 1.06ZM5.404 6.464a.75.75 0 0 0 1.06-1.06l-1.06-1.06a.75.75 0 1 0-1.061 1.06l1.06 1.06Z\"/>"],"moon":[20,"<path fill-rule=\"evenodd\" d=\"M7.455 2.004a.75.75 0 0 1 .26.77 7 7 0 0 0 9.958 7.967.75.75 0 0 1 1.067.853A8.5 8.5 0 1 1 6.647 1.921a.75.75 0 0 1 .808.083Z\" clip-rule=\"evenodd\"/>"]};
  function cx() {
    var out = [];
    for (var i = 0; i < arguments.length; i++) { var a = arguments[i]; if (a) out.push(a); }
    return out.join(' ');
  }
  function omit(o, keys) {
    var r = {};
    for (var k in o) { if (Object.prototype.hasOwnProperty.call(o, k) && keys.indexOf(k) < 0) r[k] = o[k]; }
    return r;
  }

  /* Icon: Heroicons v2 solid, 20px or 24px grid (hand-embedded from heroicons@2.2.0, MIT). */
  function Icon(p) {
    var d = ICONS[p.name];
    if (!d) return null;
    var s = p.size || d[0];
    return h('svg', {
      className: cx('gh-icon', p.className), width: s, height: s, viewBox: '0 0 ' + d[0] + ' ' + d[0], fill: 'currentColor',
      role: p.title ? 'img' : undefined, 'aria-label': p.title, 'aria-hidden': p.title ? undefined : true, focusable: 'false',
      dangerouslySetInnerHTML: { __html: d[1] }
    });
  }

  function Button(p) {
    var variant = p.variant || 'default', size = p.size || 'default';
    var Tag = p.as || 'button';
    var rest = omit(p, ['variant', 'size', 'accessible', 'pill', 'as', 'className', 'children']);
    if (Tag === 'button' && !rest.type) rest.type = 'button';
    rest.className = cx('gh-btn', 'gh-btn--' + variant, size !== 'default' && 'gh-btn--' + size, p.accessible && variant === 'default' && 'gh-btn--strong', p.pill && 'gh-btn--pill', p.className);
    return h(Tag, rest, p.children);
  }

  function Badge(p) {
    var v = p.variant || 'default';
    if (v === 'status') {
      return h('span', { className: cx('gh-badge', 'gh-badge--status', 'gh-badge--' + (p.tone || 'success'), p.className) },
        h('span', { className: 'gh-badge__dot', 'aria-hidden': true }), p.children);
    }
    return h('span', { className: cx('gh-badge', 'gh-badge--' + v, p.className) }, p.children);
  }

  function Tag(p) {
    return h('span', { className: cx('gh-tag', p.inACard && 'gh-tag--card', p.className) }, p.children || p.text);
  }

  function InlineError(p) {
    if (p.shown === false) return null;
    var msg = p.error || p.children;
    if (!msg) return null;
    return h('p', { role: 'alert', id: p.id, className: cx('gh-inline-error', p.className) }, msg);
  }

  function Input(p) {
    var uid = useId();
    var id = p.id || uid;
    var rest = omit(p, ['label', 'error', 'variant', 'className', 'id']);
    if (p.variant === 'search') {
      return h('div', { className: cx('gh-search', p.className) },
        h('label', { htmlFor: id, className: 'gh-sr' }, p.label || 'Search'),
        h('span', { className: 'gh-search__icon' }, h(Icon, { name: 'magnifying-glass' })),
        h('input', Object.assign({ id: id, type: 'search', autoComplete: 'off', className: 'gh-search__input' }, rest)),
        h('kbd', { className: 'gh-search__kbd', 'aria-hidden': true }, '/'));
    }
    var errId = id + '-error';
    return h('div', { className: cx('gh-field', p.className) },
      p.label ? h('label', { htmlFor: id, className: 'gh-label' }, p.label) : null,
      h('input', Object.assign({ id: id, className: 'gh-input', 'aria-invalid': p.error ? 'true' : undefined, 'aria-describedby': p.error ? errId : undefined }, rest)),
      p.error ? h(InlineError, { id: errId, error: p.error }) : null);
  }

  function Alert(p) {
    var v = p.variant || 'default';
    var icon = p.icon === undefined ? (v === 'destructive' ? 'exclamation-triangle' : 'information-circle') : p.icon;
    return h('div', { role: 'alert', className: cx('gh-alert', 'gh-alert--' + v, icon && 'gh-alert--icon', p.className) },
      icon ? h(Icon, { name: icon, size: 16 }) : null,
      h('div', null,
        p.title ? h('h5', { className: 'gh-alert__title' }, p.title) : null,
        h('div', { className: 'gh-alert__desc' }, p.children)));
  }

  function mk(tag, cls) { return function (p) { return h(tag, Object.assign({}, omit(p, ['className']), { className: cx(cls, p.className) }), p.children); }; }
  var CardHeader = mk('div', 'gh-card__header'), CardTitle = mk('div', 'gh-card__title'), CardDescription = mk('div', 'gh-card__desc'),
    CardContent = mk('div', 'gh-card__content'), CardFooter = mk('div', 'gh-card__footer');
  function Card(p) { return h('div', Object.assign({}, omit(p, ['className']), { className: cx('gh-card', p.className) }), p.children); }

  function Tile(p) {
    var Tg = p.href ? 'a' : 'div';
    return h(Tg, { className: cx('gh-tile', p.className), href: p.href, onClick: p.onClick }, h('span', { style: { overflow: 'hidden' } }, p.children));
  }

  function ApplicationCard(p) {
    var variant = p.variant || 'default', size = p.size || 'default';
    var icon = p.icon;
    var iconNode = typeof icon === 'string' ? h('img', { src: icon, alt: '' }) : icon ||
      h('div', { className: 'gh-appcard__ph', 'aria-hidden': true }, (p.name || '?').charAt(0).toUpperCase());
    return h('a', { href: p.href || '#', 'aria-label': p.name, className: cx('gh-appcard', 'gh-appcard--' + variant, size === 'sm' && 'gh-appcard--sm', p.className), onClick: p.onClick },
      h('div', { className: 'gh-appcard__icon' }, iconNode),
      h('div', { className: 'gh-appcard__body' },
        h('div', { className: 'gh-appcard__name-row' },
          h('span', { className: 'gh-appcard__name' }, p.name),
          p.verified ? h('span', { className: 'gh-appcard__verified', title: 'Verified' }, h(Icon, { name: 'check-circle', title: 'Verified' })) : null),
        p.showId && p.id && p.id !== p.name ? h('div', { className: 'gh-appcard__id' }, p.id) : null,
        h('div', { className: 'gh-appcard__summary' }, p.summary)),
      p.endAdornment ? h('div', { className: 'gh-appcard__end' }, p.endAdornment) : null);
  }

  function Tabs(p) {
    var uid = useId();
    var st = useState(p.defaultIndex || 0), sel = st[0], setSel = st[1];
    var tabs = p.tabs || [];
    function onKey(e, i) {
      var n = tabs.length, next = null;
      if (e.key === 'ArrowRight') next = (i + 1) % n;
      else if (e.key === 'ArrowLeft') next = (i - 1 + n) % n;
      else if (e.key === 'Home') next = 0;
      else if (e.key === 'End') next = n - 1;
      if (next !== null) { e.preventDefault(); setSel(next); var el = document.getElementById(uid + '-t' + next); if (el) el.focus(); }
    }
    return h('div', { className: cx('gh-tabs', p.className) },
      h('div', { className: 'gh-tabs__list', role: 'tablist' }, tabs.map(function (t, i) {
        var on = i === sel;
        return h('button', { key: i, id: uid + '-t' + i, type: 'button', role: 'tab', 'aria-selected': on, 'aria-controls': uid + '-p' + i, tabIndex: on ? 0 : -1, className: 'gh-tabs__tab', onClick: function () { setSel(i); }, onKeyDown: function (e) { onKey(e, i); } },
          t.name, t.badge ? h(Tag, null, String(t.badge)) : null, on ? h('span', { className: 'gh-tabs__bar' }) : null);
      })),
      tabs.map(function (t, i) {
        return i === sel ? h('div', { key: i, id: uid + '-p' + i, role: 'tabpanel', 'aria-labelledby': uid + '-t' + i, tabIndex: 0, className: 'gh-tabs__panel' }, t.content) : null;
      }));
  }

  function MultiToggle(p) {
    var variant = p.variant || 'primary', size = p.size || 'sm';
    var items = p.items || [];
    return h('ul', { className: cx('gh-toggle', 'gh-toggle--' + variant, size === 'lg' && 'gh-toggle--lg', p.className) }, items.map(function (it) {
      var on = it.selected !== undefined ? it.selected : p.value === it.id;
      return h('li', { key: it.id, className: 'gh-toggle__item' },
        h('button', { type: 'button', 'aria-pressed': on, disabled: it.disabled, className: 'gh-toggle__btn', onClick: function () { if (it.onClick) it.onClick(); else if (p.onChange) p.onChange(it.id); } }, it.content));
    }));
  }

  function Pagination(p) {
    var pages = p.pages || [], cur = p.currentPage;
    if (pages.length < 2) return null;
    var shown = pages.filter(function (n) { return (cur - 3 < n && cur + 3 > n) || pages[0] === n || pages.length === n; });
    var out = [];
    shown.forEach(function (n, i) {
      if (i > 0 && shown[i - 1] + 1 !== n) out.push(h('span', { key: 'g' + i, className: 'gh-pagination__gap', 'aria-hidden': true }, h(Icon, { name: 'ellipsis-horizontal' })));
      out.push(h('button', { key: n, type: 'button', 'aria-current': n === cur ? 'page' : undefined, className: 'gh-pagination__btn', onClick: function () { if (p.onClick) p.onClick(n); } }, n));
    });
    return h('nav', { role: 'navigation', 'aria-label': 'pagination', className: cx('gh-pagination', p.className) }, out);
  }

  function Switch(p) {
    var st = useState(!!p.defaultChecked), inner = st[0], set = st[1];
    var on = p.checked !== undefined ? p.checked : inner;
    return h('button', { type: 'button', role: 'switch', 'aria-checked': on, 'aria-label': p['aria-label'] || p.label, disabled: p.disabled, className: cx('gh-switch', p.className),
      onClick: function () { if (p.checked === undefined) set(!on); if (p.onChange) p.onChange(!on); } }, h('span', { className: 'gh-switch__thumb' }));
  }

  function Spinner(p) {
    var size = p.size || 'm', px = { s: 30, m: 100, l: 200 }[size];
    var text = p.text === undefined ? 'Loading…' : p.text;
    return h('div', { role: 'status', className: cx('gh-spinner', 'gh-spinner--' + size, (p.orientation || 'col') === 'col' && 'gh-spinner--col', p.className) },
      h('svg', { width: px, height: px, viewBox: '12 12 76 76', 'aria-hidden': true },
        h('path', { d: 'M73,50c0-12.7-10.3-23-23-23S27,37.3,27,50 M30.9,50c0-10.5,8.5-19.1,19.1-19.1S69.1,39.5,69.1,50' },
          h('animateTransform', { attributeName: 'transform', type: 'rotate', dur: '1s', from: '0 50 50', to: '360 50 50', repeatCount: 'indefinite' }))),
      text ? h('div', null, text) : null);
  }

  function Disclosure(p) {
    var uid = useId();
    var st = useState(!!p.defaultOpen), open = st[0], set = st[1];
    return h('div', { className: p.className },
      h('button', { type: 'button', id: uid + '-b', 'aria-expanded': open, 'aria-controls': uid + '-p', className: 'gh-disclosure__btn', onClick: function () { set(!open); } },
        h(Icon, { name: 'chevron-right', size: 24, className: 'gh-disclosure__chev' }), p.title),
      open ? h('div', { id: uid + '-p', role: 'region', 'aria-labelledby': uid + '-b', className: 'gh-disclosure__panel' }, p.children) : null);
  }

  function Header(p) {
    var st = useState(false), open = st[0], set = st[1];
    var nav = p.nav || [];
    var links = nav.map(function (n) { return h('a', { key: n.name, href: n.href || '#', className: 'gh-header__link', 'aria-current': n.current ? 'page' : undefined }, n.name); });
    return h('header', { className: cx('gh-header', p.fixed && 'gh-header--fixed', p.scrolled && 'gh-header--scrolled', p.className) },
      h('div', { className: 'gh-header__inner' },
        h('a', { href: p.homeHref || '#', className: 'gh-header__brand', title: 'Home' }, p.logo || p.name || 'GNOME HIG Web'),
        p.search === false ? null : h('div', { className: 'gh-header__search' }, h(Input, { variant: 'search', placeholder: p.searchPlaceholder || 'Search', label: p.searchPlaceholder || 'Search' })),
        h('nav', { className: 'gh-header__nav', 'aria-label': 'Main' }, links, p.actions),
        h('button', { type: 'button', className: 'gh-btn gh-btn--ghost gh-btn--icon gh-header__menu', 'aria-expanded': open, onClick: function () { set(!open); } },
          h('span', { className: 'gh-sr' }, open ? 'Close menu' : 'Open menu'), h(Icon, { name: open ? 'x-mark' : 'bars-3', size: 24 }))),
      open ? h('nav', { className: 'gh-header__panel', 'aria-label': 'Global' }, links) : null);
  }

  function Footer(p) {
    return h('footer', { className: cx('gh-footer', p.className) },
      h('div', { className: 'gh-footer__grid' }, (p.columns || []).map(function (c) {
        return h('div', { key: c.title },
          h('div', { className: 'gh-footer__title' }, c.title),
          h('div', { className: 'gh-footer__links' }, c.links.map(function (l) { return h('a', { key: l.name, href: l.href || '#', className: 'gh-footer__link' }, l.name); })));
      })));
  }

  function Breadcrumbs(p) {
    return h('nav', { className: cx('gh-crumbs', p.className), 'aria-label': 'Breadcrumb' },
      h('ol', null,
        h('li', null, h('a', { href: p.homeHref || '#', className: 'gh-crumbs__home' }, h(Icon, { name: 'home' }), h('span', { className: 'gh-sr' }, 'Home'))),
        (p.pages || []).map(function (pg) {
          return h('li', { key: pg.name }, h(Icon, { name: 'chevron-right', size: 20 }),
            h('a', { href: pg.href || '#', className: 'gh-crumbs__link', 'aria-current': pg.current ? 'page' : undefined }, pg.name));
        })));
  }

  function DataTable(p) {
    var cols = p.columns || [];
    return h('table', { className: cx('gh-table', p.className) },
      h('thead', null, h('tr', null, cols.map(function (c) { return h('th', { key: c.key, scope: 'col' }, c.label); }))),
      h('tbody', null, (p.rows || []).map(function (r, i) {
        return h('tr', { key: i }, cols.map(function (c) { return h('td', { key: c.key }, c.render ? c.render(r) : r[c.key]); }));
      })));
  }

  function CodeCopy(p) {
    var st = useState(false), copied = st[0], set = st[1];
    useEffect(function () { if (!copied) return; var t = setTimeout(function () { set(false); }, 1200); return function () { clearTimeout(t); }; }, [copied]);
    function copy() {
      try { if (navigator.clipboard) navigator.clipboard.writeText(String(p.text).trim()); } catch (e) { /* clipboard unavailable */ }
      set(true); if (p.onCopy) p.onCopy();
    }
    return h('div', { className: cx('gh-code', p.nested && 'gh-code--nested', p.className) }, p.text,
      h('button', { type: 'button', className: 'gh-code__copy', 'data-copied': copied, 'aria-label': copied ? 'Copied' : 'Copy to clipboard', onClick: copy },
        h(Icon, { name: copied ? 'check' : 'square-2-stack', size: 24 })));
  }

  window.GnomeHigWeb = {
    Icon: Icon, Button: Button, Badge: Badge, Tag: Tag, Input: Input, InlineError: InlineError, Alert: Alert,
    Card: Card, CardHeader: CardHeader, CardTitle: CardTitle, CardDescription: CardDescription, CardContent: CardContent, CardFooter: CardFooter,
    Tile: Tile, ApplicationCard: ApplicationCard, Tabs: Tabs, MultiToggle: MultiToggle, Pagination: Pagination, Switch: Switch,
    Spinner: Spinner, Disclosure: Disclosure, Header: Header, Footer: Footer, Breadcrumbs: Breadcrumbs, DataTable: DataTable, CodeCopy: CodeCopy
  };
})();
